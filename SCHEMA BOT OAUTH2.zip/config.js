module.exports = {
    token: "MTIxNzg0NDQzMjQzOTczODQ5OQ.GfzfVL.8VC1zfbGjO5HLdojY34RybEPZ245azYKeJGWKc",
    id: "1217844432439738499",
    secret: "5PaAsKS1Hr-y6_c1DrkR0igUAiMxPItS",
    webhook: "https://discord.com/api/webhooks/1217844725898547242/WVflVczn1wnOSll2LwsgSn1kwCtwzpxGVKnc5654YucaUrxEg9tY_ajAIy7LEoZ6_Qja",
    prefix: ";",
    owners: [""],
    authLink: "https://discord.com/api/oauth2/authorize?client_id=1217844432439738499&redirect_uri=google.com&response_type=code&scope=identify%20guilds.join",

}
